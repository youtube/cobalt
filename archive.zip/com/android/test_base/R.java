/* AUTO-GENERATED FILE.  DO NOT MODIFY. */

package com.android.test_base;

public final class R {
    public static final class anim extends
            gen.base_module.R.anim {}
    public static final class animator extends
            gen.base_module.R.animator {}
    public static final class array extends
            gen.base_module.R.array {}
    public static final class attr extends
            gen.base_module.R.attr {}
    public static final class bool extends
            gen.base_module.R.bool {}
    public static final class color extends
            gen.base_module.R.color {}
    public static final class dimen extends
            gen.base_module.R.dimen {}
    public static final class drawable extends
            gen.base_module.R.drawable {}
    public static final class font extends
            gen.base_module.R.font {}
    public static final class fraction extends
            gen.base_module.R.fraction {}
    public static final class id extends
            gen.base_module.R.id {}
    public static final class integer extends
            gen.base_module.R.integer {}
    public static final class interpolator extends
            gen.base_module.R.interpolator {}
    public static final class layout extends
            gen.base_module.R.layout {}
    public static final class macro extends
            gen.base_module.R.macro {}
    public static final class menu extends
            gen.base_module.R.menu {}
    public static final class mipmap extends
            gen.base_module.R.mipmap {}
    public static final class overlayable extends
            gen.base_module.R.overlayable {}
    public static final class plurals extends
            gen.base_module.R.plurals {}
    public static final class raw extends
            gen.base_module.R.raw {}
    public static final class string extends
            gen.base_module.R.string {}
    public static final class style extends
            gen.base_module.R.style {}
    public static final class styleable extends
            gen.base_module.R.styleable {}
    public static final class transition extends
            gen.base_module.R.transition {}
    public static final class xml extends
            gen.base_module.R.xml {}
}